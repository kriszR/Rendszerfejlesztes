﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MoodleRestAPI.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NeptunCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Gender = table.Column<int>(type: "int", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CourseId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentId);
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseId", "DateOfBirth", "Email", "FirstName", "Gender", "LastName", "NeptunCode" },
                values: new object[] { 1, 1, new DateTime(2003, 3, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "attila@example.com", "Attila", 0, "Vegh", "MYWTLT" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseId", "DateOfBirth", "Email", "FirstName", "Gender", "LastName", "NeptunCode" },
                values: new object[] { 2, 2, new DateTime(2003, 10, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "kristof@example.com", "Kristof", 0, "Varga", "DHKOHH" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentId", "CourseId", "DateOfBirth", "Email", "FirstName", "Gender", "LastName", "NeptunCode" },
                values: new object[] { 3, 3, new DateTime(2003, 10, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "mate@example.com", "Mate", 0, "Valcz", "RYRHJ0" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
