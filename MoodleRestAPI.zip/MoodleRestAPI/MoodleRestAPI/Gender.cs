﻿namespace MoodleRestAPI
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
