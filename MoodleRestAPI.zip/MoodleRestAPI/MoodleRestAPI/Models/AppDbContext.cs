﻿using Microsoft.EntityFrameworkCore;

namespace MoodleRestAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) 
            : base(options)
        { 
            
        }
        public DbSet<Student> Students { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = 1,
                    NeptunCode = "MYWTLT",
                    FirstName = "Attila",
                    LastName = "Vegh",
                    Email = "attila@example.com",
                    Gender = Gender.Male,
                    DateOfBirth = new DateTime(2003, 03, 18),
                    CourseId = 1,
                });

            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = 2,
                    NeptunCode = "DHKOHH",
                    FirstName = "Kristof",
                    LastName = "Varga",
                    Email = "kristof@example.com",
                    Gender = Gender.Male,
                    DateOfBirth = new DateTime(2003, 10, 16),
                    CourseId = 2,
                });

            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = 3,
                    NeptunCode = "RYRHJ0",
                    FirstName = "Mate",
                    LastName = "Valcz",
                    Email = "mate@example.com",
                    Gender = Gender.Male,
                    DateOfBirth = new DateTime(2003, 10, 05),
                    CourseId = 3,
                });


        }
    }
}
